import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class cstudiosmodlauncher extends PApplet {

PFont f;
int cool = 0;

public void setup(){
  
  background(200,200,15);
  printArray(PFont.list());
  f = createFont("Candara Bold", 20);
  textFont(f);
}

public void draw(){
  fill(0);
  text("Welcome to the CStudiosMod Launcher.                                                         Launcher Version: 1.0",30,25);
  stroke(255,100,100);
  fill(255,30,30);
  rect(20,575,250,65);
  rect(570,575,250,65);
  fill(180,66,235);
  text("Latest CStudiosMod 2 Build",30,615);
  text("Latest CStudiosMod 1 Build",580,615);
  if(mousePressed){
    if((mouseX <= 270 && mouseX >= 20) && (mouseY <= 640 && mouseY >= 575)){
      if(cool == 0){
        link("https://teamcstudios.pro/CStudiosMod2/latest-build");
      }
      cool = 10;
    }
    if((mouseX <= 820 && mouseX >= 570) && (mouseY <= 640 && mouseY >= 575)){
      if(cool == 0){
        link("https://github.com/TeamCstudios/CStudiosMod/raw/master/downloads/cstudiosmod_1.0.1.jar");
      }
      cool = 10;
    }
  }
  if(cool > 0){
    cool--; 
  }
}
  public void settings() {  size (840,650); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "cstudiosmodlauncher" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
